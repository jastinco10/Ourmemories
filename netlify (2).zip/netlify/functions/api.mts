import type { Config } from "@netlify/functions";
import { getDatabase } from "@netlify/database";
import { getStore } from "@netlify/blobs";
import { createHash, createHmac, randomBytes, randomUUID, scryptSync, timingSafeEqual } from "node:crypto";

// SHA-256 of "ourmemories|<username>|<password>" — checked on the server
const LOGIN_HASH = "bd4a021757c2344be3dd6b8268805a0df50e6b4709c20a1a1c080513b6a61656";
const SECRET = process.env.SESSION_SECRET || LOGIN_HASH;
const COOKIE = "om_session";
const SESSION_DAYS = 30;
const MAX_MEDIA_BYTES = 10_000_000; // 10MB per media item
const DEFAULT_SETTINGS = { n1: "Jastin", n2: "Josma", start: "" };
const INVITE_DAYS = 7;
const ROLES = ["viewer", "editor"];

type Session = { user: string; role: "owner" | "editor" | "viewer" };

const db = getDatabase();
const photos = () => getStore("photos");

let dbReady: Promise<void> | null = null;
function ensureDb() {
  if (!dbReady) {
    dbReady = (async () => {
      try {
        await db.sql`
          CREATE TABLE IF NOT EXISTS chat_messages (
            id TEXT PRIMARY KEY,
            sender TEXT NOT NULL,
            message TEXT NOT NULL,
            created_at TIMESTAMPTZ DEFAULT NOW()
          );
        `;
        await db.sql`
          ALTER TABLE memories ADD COLUMN IF NOT EXISTS media JSONB DEFAULT '[]'::jsonb;
        `;
      } catch (e) {
        console.error("ensureDb error:", e);
      }
    })();
  }
  return dbReady;
}

const sign = (payload: string) => createHmac("sha256", SECRET).update(payload).digest("base64url");

function makeToken(user: string, member = false) {
  const body = { u: user, exp: Date.now() + SESSION_DAYS * 864e5, ...(member ? { m: 1 } : {}) };
  const payload = Buffer.from(JSON.stringify(body)).toString("base64url");
  return `${payload}.${sign(payload)}`;
}

async function readSession(req: Request): Promise<Session | null> {
  const raw = (req.headers.get("cookie") || "").split(/;\s*/).find((c) => c.startsWith(COOKIE + "="));
  if (!raw) return null;
  const [payload, sig] = raw.slice(COOKIE.length + 1).split(".");
  if (!payload || !sig) return null;
  const expected = Buffer.from(sign(payload));
  const given = Buffer.from(sig);
  if (expected.length !== given.length || !timingSafeEqual(expected, given)) return null;
  let data: any;
  try {
    data = JSON.parse(Buffer.from(payload, "base64url").toString());
  } catch {
    return null;
  }
  if (!(data.exp > Date.now())) return null;
  if (!data.m) return { user: String(data.u), role: "owner" };
  const [row] = await db.sql`SELECT role FROM users WHERE username = ${String(data.u)}`;
  return row ? { user: String(data.u), role: row.role === "editor" ? "editor" : "viewer" } : null;
}

const sha = (s: string) => createHash("sha256").update(s).digest("hex");

function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  return `${salt}:${scryptSync(password, salt, 32).toString("hex")}`;
}

function checkPassword(password: string, stored: string) {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const given = scryptSync(password, salt, 32);
  const expected = Buffer.from(hash, "hex");
  return expected.length === given.length && timingSafeEqual(expected, given);
}

async function findInvite(token: unknown) {
  const t = str(token, 200);
  if (!t) return null;
  const [row] = await db.sql`SELECT id, role, created_by FROM invites WHERE token_hash = ${sha(t)} AND expires_at > NOW()`;
  return row || null;
}

async function loadAccess() {
  const members = await db.sql`SELECT username, role, invited_by, created_at FROM users ORDER BY created_at`;
  const invites = await db.sql`SELECT id, role, created_by, created_at, expires_at FROM invites
    WHERE expires_at > NOW() ORDER BY created_at DESC`;
  return {
    members: members.map((r: any) => ({ user: r.username, role: r.role, by: r.invited_by, since: r.created_at })),
    invites: invites.map((r: any) => ({ id: r.id, role: r.role, by: r.created_by, expires: r.expires_at })),
  };
}

const cookie = (value: string, maxAge: number) =>
  `${COOKIE}=${value}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;

const str = (v: unknown, max = 20000) => String(v ?? "").slice(0, max);

// Stores an image or video data: URL in Blobs and returns key and media kind
async function saveMedia(dataUrl: unknown): Promise<{ key: string; type: "image" | "video" } | null> {
  const s = String(dataUrl || "");
  const m = /^data:(image|video)\/([a-z0-9+.-]+);base64,(.+)$/i.exec(s);
  if (!m) return null;
  const kind = m[1].toLowerCase() === "video" ? "video" : "image";
  const mime = `${m[1]}/${m[2]}`;
  const bytes = Buffer.from(m[3], "base64");
  if (bytes.length > MAX_MEDIA_BYTES) throw new Error("Media file exceeds size limit");
  const key = randomUUID();
  await photos().set(key, new Uint8Array(bytes).buffer as ArrayBuffer, {
    metadata: { type: mime, kind }
  });
  return { key, type: kind };
}

async function savePhoto(dataUrl: unknown): Promise<string> {
  const saved = await saveMedia(dataUrl);
  return saved ? saved.key : "";
}

const photoUrl = (key: string) => (key ? `/api/photos/${key}` : "");

async function loadState(me: Session) {
  await ensureDb();
  const rows = await db.sql`SELECT id, title, body, date, photo, media, added_by FROM memories ORDER BY date DESC, created_at DESC`;
  const settings = await db.sql`SELECT key, value FROM settings`;
  const byKey = Object.fromEntries(settings.map((r: any) => [r.key, r.value]));
  return {
    me,
    settings: { ...DEFAULT_SETTINGS, ...(byKey.couple || {}) },
    cover: photoUrl(byKey.cover?.photo || ""),
    memories: rows.map((r: any) => {
      let media: { type: string; url: string }[] = [];
      if (Array.isArray(r.media) && r.media.length > 0) {
        media = r.media.map((m: any) => ({
          type: m.type === "video" ? "video" : "image",
          url: photoUrl(m.key),
        }));
      } else if (r.photo) {
        media = [{ type: "image", url: photoUrl(r.photo) }];
      }
      return {
        id: r.id,
        title: r.title,
        text: r.body,
        date: r.date,
        photo: photoUrl(r.photo),
        media,
        by: r.added_by,
      };
    }),
  };
}

async function setSetting(key: string, value: unknown) {
  await db.sql`INSERT INTO settings (key, value) VALUES (${key}, ${JSON.stringify(value)}::jsonb)
    ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value`;
}

export default async (req: Request) => {
  const route = new URL(req.url).pathname.replace(/^\/api\/?/, "").replace(/\/+$/, "");
  const method = req.method;

  if (route === "login" && method === "POST") {
    const { username, password } = await req.json().catch(() => ({}));
    const user = str(username, 200).trim().toLowerCase();
    const pass = str(password, 500);
    if (sha(`ourmemories|${user}|${pass}`) === LOGIN_HASH) {
      return Response.json({ ok: true }, { headers: { "set-cookie": cookie(makeToken(user), SESSION_DAYS * 86400) } });
    }
    const [row] = await db.sql`SELECT pass_hash FROM users WHERE username = ${user}`;
    if (!row || !checkPassword(pass, row.pass_hash)) {
      return Response.json({ error: "Wrong username or password." }, { status: 401 });
    }
    return Response.json({ ok: true }, { headers: { "set-cookie": cookie(makeToken(user, true), SESSION_DAYS * 86400) } });
  }

  // Public: lets the invite page check a link before asking for a username and password.
  const inv = /^invite\/([A-Za-z0-9_-]+)$/.exec(route);
  if (inv && method === "GET") {
    const row = await findInvite(inv[1]);
    if (!row) return Response.json({ error: "This invite link is invalid or has expired." }, { status: 404 });
    return Response.json({ role: row.role, by: row.created_by });
  }

  if (route === "join" && method === "POST") {
    const { token, username, password } = await req.json().catch(() => ({}));
    const row = await findInvite(token);
    if (!row) return Response.json({ error: "This invite link is invalid or has expired." }, { status: 404 });
    const user = str(username, 200).trim().toLowerCase();
    const pass = str(password, 500);
    if (!/^[a-z0-9._-]{2,40}$/.test(user)) {
      return Response.json({ error: "Username must be 2–40 letters, numbers, dots, dashes or underscores." }, { status: 400 });
    }
    if (pass.length < 8) return Response.json({ error: "Password must be at least 8 characters." }, { status: 400 });
    const [taken] = await db.sql`SELECT 1 FROM users WHERE username = ${user}`;
    if (taken) return Response.json({ error: "That username is already taken." }, { status: 409 });
    const [claimed] = await db.sql`DELETE FROM invites WHERE id = ${row.id} RETURNING role, created_by`;
    if (!claimed) return Response.json({ error: "This invite link has already been used." }, { status: 410 });
    await db.sql`INSERT INTO users (username, pass_hash, role, invited_by)
      VALUES (${user}, ${hashPassword(pass)}, ${claimed.role}, ${claimed.created_by})`;
    return Response.json({ ok: true }, { headers: { "set-cookie": cookie(makeToken(user, true), SESSION_DAYS * 86400) } });
  }

  if (route === "logout") {
    return Response.json({ ok: true }, { headers: { "set-cookie": cookie("", 0) } });
  }

  const me = await readSession(req);
  if (!me) return Response.json({ error: "Not signed in" }, { status: 401 });
  const user = me.user;

  try {
    if (route === "state" && method === "GET") {
      return Response.json(await loadState(me), { headers: { "cache-control": "no-store" } });
    }

    // Media streaming (images & videos)
    const pic = /^photos\/([0-9a-f-]{36})$/i.exec(route);
    if (pic && method === "GET") {
      const found = await photos().getWithMetadata(pic[1], { type: "arrayBuffer" });
      if (!found) return new Response("Not found", { status: 404 });
      const contentType = String(found.metadata?.type || "image/jpeg");
      return new Response(found.data, {
        headers: {
          "content-type": contentType,
          "cache-control": "private, max-age=31536000, immutable",
        },
      });
    }

    // Chat messages (viewers can read)
    if (route === "chat" && method === "GET") {
      await ensureDb();
      const recent = await db.sql`
        SELECT id, sender, message, created_at
        FROM chat_messages
        ORDER BY created_at DESC
        LIMIT 80
      `;
      const messages = recent.reverse().map((r: any) => ({
        id: r.id,
        sender: r.sender,
        text: r.message,
        time: r.created_at,
      }));
      return Response.json({ messages }, { headers: { "cache-control": "no-store" } });
    }

    // Everything below modifies data: view-only members stop here
    if (me.role === "viewer") return Response.json({ error: "You have view-only access." }, { status: 403 });

    // Send chat message
    if (route === "chat" && method === "POST") {
      await ensureDb();
      const { text } = await req.json().catch(() => ({}));
      const msgText = str(text, 2000).trim();
      if (!msgText) return Response.json({ error: "Message cannot be empty." }, { status: 400 });
      const id = randomUUID();
      const [created] = await db.sql`
        INSERT INTO chat_messages (id, sender, message, created_at)
        VALUES (${id}, ${user}, ${msgText}, NOW())
        RETURNING id, sender, message, created_at
      `;
      return Response.json({
        message: {
          id: created.id,
          sender: created.sender,
          text: created.message,
          time: created.created_at,
        }
      }, { status: 201 });
    }

    // Upload individual media file (for multi-upload support without exceeding payload limit)
    if (route === "upload" && method === "POST") {
      const { data } = await req.json().catch(() => ({}));
      const saved = await saveMedia(data);
      if (!saved) return Response.json({ error: "Invalid media file" }, { status: 400 });
      return Response.json({ key: saved.key, type: saved.type, url: photoUrl(saved.key) }, { status: 201 });
    }

    if (route === "access" && method === "GET") {
      return Response.json(await loadAccess(), { headers: { "cache-control": "no-store" } });
    }

    if (route === "invites" && method === "POST") {
      const { role } = await req.json().catch(() => ({}));
      const token = randomBytes(24).toString("base64url");
      await db.sql`INSERT INTO invites (token_hash, role, created_by, expires_at)
        VALUES (${sha(token)}, ${ROLES.includes(role) ? role : "viewer"}, ${user}, NOW() + ${INVITE_DAYS + " days"}::interval)`;
      return Response.json({ token, ...(await loadAccess()) }, { status: 201 });
    }

    const invDel = /^invites\/([0-9a-f-]{36})$/i.exec(route);
    if (invDel && method === "DELETE") {
      await db.sql`DELETE FROM invites WHERE id = ${invDel[1]}`;
      return Response.json(await loadAccess());
    }

    const member = /^members\/([a-z0-9._-]{1,40})$/.exec(route);
    if (member && method === "PATCH") {
      const { role } = await req.json().catch(() => ({}));
      if (!ROLES.includes(role)) return Response.json({ error: "Invalid role" }, { status: 400 });
      if (member[1] === user) return Response.json({ error: "You can’t change your own access." }, { status: 400 });
      await db.sql`UPDATE users SET role = ${role} WHERE username = ${member[1]}`;
      return Response.json(await loadAccess());
    }
    if (member && method === "DELETE") {
      if (member[1] === user) return Response.json({ error: "You can’t remove yourself." }, { status: 400 });
      await db.sql`DELETE FROM users WHERE username = ${member[1]}`;
      return Response.json(await loadAccess());
    }

    if (route === "settings" && method === "PUT") {
      const b = await req.json();
      await setSetting("couple", {
        n1: str(b.n1, 80).trim() || DEFAULT_SETTINGS.n1,
        n2: str(b.n2, 80).trim() || DEFAULT_SETTINGS.n2,
        start: /^\d{4}-\d{2}-\d{2}$/.test(b.start) ? b.start : "",
      });
      return Response.json(await loadState(me));
    }

    if (route === "cover" && method === "PUT") {
      const { photo } = await req.json();
      const key = await savePhoto(photo);
      if (!key) return Response.json({ error: "Invalid photo" }, { status: 400 });
      const old = await db.sql`SELECT value FROM settings WHERE key = 'cover'`;
      await setSetting("cover", { photo: key });
      if (old[0]?.value?.photo) await photos().delete(old[0].value.photo);
      return Response.json(await loadState(me));
    }

    // Save memory with multiple photos and videos
    if (route === "memories" && method === "POST") {
      await ensureDb();
      const b = await req.json();
      const title = str(b.title, 300).trim();
      const text = str(b.text).trim();
      if (!title && !text) return Response.json({ error: "Empty memory" }, { status: 400 });

      const mediaList: { key: string; type: "image" | "video" }[] = [];
      if (Array.isArray(b.media)) {
        for (const item of b.media.slice(0, 15)) {
          if (item.key) {
            mediaList.push({ key: str(item.key, 40), type: item.type === "video" ? "video" : "image" });
          } else if (item.data) {
            const saved = await saveMedia(item.data);
            if (saved) mediaList.push(saved);
          }
        }
      } else if (b.photo) {
        const key = await savePhoto(b.photo);
        if (key) mediaList.push({ key, type: "image" });
      }

      const primaryPhoto = mediaList.find((m) => m.type === "image")?.key || mediaList[0]?.key || "";
      await db.sql`INSERT INTO memories (title, body, date, photo, media, added_by)
        VALUES (${title}, ${text}, ${str(b.date, 10)}, ${primaryPhoto}, ${JSON.stringify(mediaList)}::jsonb, ${user})`;
      return Response.json(await loadState(me), { status: 201 });
    }

    const mem = /^memories\/([0-9a-f-]{36})$/i.exec(route);
    if (mem && method === "PATCH") {
      const { text } = await req.json();
      await db.sql`UPDATE memories SET body = ${str(text).trim()} WHERE id = ${mem[1]}`;
      return Response.json(await loadState(me));
    }

    if (mem && method === "DELETE") {
      await ensureDb();
      const [row] = await db.sql`DELETE FROM memories WHERE id = ${mem[1]} RETURNING photo, media`;
      if (row) {
        if (Array.isArray(row.media)) {
          for (const item of row.media) {
            if (item.key) await photos().delete(item.key).catch(() => {});
          }
        }
        if (row.photo) {
          await photos().delete(row.photo).catch(() => {});
        }
      }
      return Response.json(await loadState(me));
    }

  } catch (e) {
    console.error(e);
    return Response.json({ error: (e as Error).message || "Server error" }, { status: 500 });
  }

  return Response.json({ error: "Not found" }, { status: 404 });
};

export const config: Config = {
  path: "/api/*",
};