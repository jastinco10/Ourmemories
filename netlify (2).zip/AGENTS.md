# AGENTS.md

## Architecture
- `public/index.html`: the whole frontend in one file (inline CSS and JS, no framework, no build step). Keep its compact, minified-feeling style when editing.
- `netlify/functions/api.mts`: one function mounted at `/api/*`, routed by pathname:
  - `POST /api/login`, `POST /api/logout`: login sets a signed HttpOnly cookie (`om_session`, 30 days)
  - `GET /api/state`: returns `{ settings, cover, memories }`
  - `PUT /api/settings`, `PUT /api/cover`
  - `POST /api/memories`, `PATCH|DELETE /api/memories/:id`
  - `GET /api/photos/:key`: streams a photo from the `photos` Blobs store (behind the cookie)
  - Invites: `GET /api/invite/:token` and `POST /api/join` are public; `GET /api/access`, `POST /api/invites`, `DELETE /api/invites/:id`, `PATCH|DELETE /api/members/:username` need edit access.
  - Every mutating route returns the full state so the client can just call `apply()`.
- `netlify/database/migrations/`: hand-written SQL migrations (native `@netlify/database` driver, no Drizzle). Never edit an applied migration; add a new one instead.

## Data
- `memories` table: title, body, date (YYYY-MM-DD text), photo (Blobs key), added_by (login username).
- `users` table: invited members (scrypt `salt:hash` password, role `viewer`|`editor`). `invites` table: single-use invite tokens (only the SHA-256 is stored), expire after 7 days.
- `settings` table: key/value JSONB rows, `couple` = `{ n1, n2, start }`, `cover` = `{ photo }`.
- Photos are resized in the browser, sent as data URLs, and stored as binary in Blobs. They are served through the authenticated function, not the Image CDN, because they are private.

## Non-obvious decisions
- The page originally ran inside Claude artifacts (`window.claude.use("db")`) and checked its password hash in the browser. Both now live on the server. `LOGIN_HASH` is the original hash, so the existing credentials keep working.
- Clients poll `/api/state` every 20 s, and again when the tab becomes visible, so both partners see each other's updates.
- Roles: the original `LOGIN_HASH` login is the owner (session tokens without `m`). Invited members carry `m:1` and their role is re-read from `users` on every request, so removing someone takes effect immediately. Viewers get 403 on everything except `state` and `photos`.
- Invite links use `/#invite=<token>` (hash, so the token isn't sent in request logs or referrers).
