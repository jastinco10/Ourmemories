# Our Memories ♥

A private, password-protected timeline of shared memories for two people. It has editable names, a "days together" counter, a cover photo, rotating love quotes, and memory cards with photos that both people can add, edit, and delete.

## Technologies

- A single static page (`public/index.html`), plain HTML/CSS/JS with no build step
- A Netlify Function (`netlify/functions/api.mts`) that handles login, memories, settings, and photos
- Netlify Database (Postgres) for memories and settings
- Netlify Blobs for uploaded photos

## Running locally

```bash
npm install
netlify dev
```

Then open the URL that `netlify dev` prints.

## Login

The username and password are the same ones the original page used. The server compares a SHA-256 hash, so the credentials themselves are never stored in the code. To change them, replace `LOGIN_HASH` in `netlify/functions/api.mts` with `sha256("ourmemories|<username lowercased>|<password>")`. If you set an optional `SESSION_SECRET` environment variable, it is used to sign session cookies.
